function logout() {
	var oke = confirm(" Yakin Ingin Logout?");
	if (oke) {
		document.write("Logout berhasil");
		window.location = "Login.html";
	} else {
		document.write("Disini aja");
		window.location = "home.html"
	}
}
