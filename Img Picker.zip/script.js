// JavaScript Document
function pilih(){
 var pil=document.getElementById("form1").pic.value;
  if (pil=="1")
    {
        document.getElementById("img").innerHTML="<img src='IMG/BERAS.jpg''>";
        window.alert("Ini Adalah Gambar Beras");
    }
    else if (pil=="2")
    {
        document.getElementById("img").innerHTML="<img src='IMG/MINYAK.jpg''>";
        window.alert("Ini Adalah Gambar Minyak");
    }
    else if (pil=="3")
    {
        document.getElementById("img").innerHTML="<img src='IMG/TERIGU.jpg'>";
        window.alert("Ini Adalah Gambar Terigu");
    }
    else if (pil=="4")
    {
        document.getElementById("img").innerHTML="<img src='IMG/KECAP.jpg'>";
        window.alert("Ini Adalah Gambar Kecap");
    }
    else if (pil=="5")
    {
        document.getElementById("img").innerHTML="<img src='IMG/GULA.jpg'>";
        window.alert("Ini Adalah Gambar Gula");
    }
    else if (pil=="6")
    {
        document.getElementById("img").innerHTML="<img src='IMG/GARAM.jpg'>";
        window.alert("Ini Adalah Gambar Garam");
    
    }
    else if (pil=="7")
    {
        document.getElementById("img").innerHTML="<img src='IMG/INDOMIE.jpg'>";
        window.alert("Ini Adalah Gambar Indomie");
    }else{
        document.getElementById("img").innerHTML="<img src='IMG/Pilih.jpg'>";
    }
    
}